# --------------------------------------
# FUNCTION regression_analysis
# required packages: none
# description: Run a simple regression model for Species Richness (S) vs. Abundance across all years
# inputs:
# outputs:
########################################
regression_analysis <- function(DataFrame){
  model <- lm(SpeciesRichness ~ Abundance, data = DataFrame)
  model_summary <- summary(model)
  r_squared <- model_summary$r.squared
  p_value <- coef(model_summary)[2, 4]
  return(list(r_squared = r_squared, p_value = p_value))
} # end of function regression_analysis
# --------------------------------------
# regression_analysis()
