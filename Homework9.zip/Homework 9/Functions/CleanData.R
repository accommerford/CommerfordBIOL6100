# --------------------------------------
# FUNCTION clean_data
# required packages: none
# description: Cleaning the data for any empty/missing cases
# inputs: .csv file
# outputs:
########################################
clean_data <- function(df) {
  # delete empty columns that are not needed for analysis so they don't mess up the cleaning
  delete_columns <- c("clusterCode", "identificationHistoryID")
  df <- df[, !(colnames(df) %in% delete_columns), drop = FALSE]

  # remove rows with missing values
  df <- df[complete.cases(df), ]

  return(df)
} # end of function clean_data
# --------------------------------------
# clean_data()
