# --------------------------------------
# FUNCTION calculate_species_richness
# required packages: none
# description: Calculate Species Richness for each year (Number of unique species found)
# inputs:
# outputs:
########################################
calculate_species_richness <- function(filename){
  df <- read.csv(filename)
  length(unique(df$scientificName))
} # end of function calculate_species_richness
# --------------------------------------
# calculate_species_richness()
