# --------------------------------------
# FUNCTION extract_year
# required packages: none
# description: Extract the year from each file name
# inputs:
# outputs:
########################################
extract_year <- function(filename) {
  # Use a regular expression to extract the year-month part (YYYY-MM)
  year_month <- sub(".*countdata\\.(\\d{4}-\\d{2})\\.basic.*", "\\1", filename)

  return(year_month)
}
# end of function extract_year
# --------------------------------------
# extract_year()
