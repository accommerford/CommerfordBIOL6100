# --------------------------------------
# FUNCTION calculate_abundance
# required packages: none
# description: Calculate Abundance for each year (Total number of individuals found)
# inputs:
# outputs:
########################################
calculate_abundance <- function(filename){
  df <- read.csv(filename)
  nrow(df)
} # end of function calculate_abundance
# --------------------------------------
# calculate_abundance()
