# --------------------------------------
# FUNCTION build_histogram
# required packages: none
# description: Generate histograms for both Abundance and Species Richness (S) and store the plots
# inputs:
# outputs:
########################################
build_histogram <- function(DataFrame){
  S <- ggplot(data = DataFrame) +
    aes(x = SpeciesRichness) +
    geom_histogram(fill = "cadetblue1")
  ggsave(filename = "SpeciesRichness.pdf", plot = S, path = "~/Desktop/spring 2025/BIOL 6100/Homework 9/Plots")

  R <- ggplot(data = DataFrame) +
    aes(x  = Abundance) +
    geom_histogram(fill = "coral")
  ggsave(filename = "Abundance.pdf", plot = R, path = "~/Desktop/spring 2025/BIOL 6100/Homework 9/Plots")

} # end of function build_histogram
# --------------------------------------
# build_histogram()
