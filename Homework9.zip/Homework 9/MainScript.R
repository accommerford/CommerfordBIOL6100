# load upscaler
library(upscaler)

# Set the working directory
setwd("~/Desktop/spring 2025/BIOL 6100/Homework 9/NEON_count-landbird")
OriginalData <- getwd()
folders <- list.files(OriginalData)

setwd("~/Desktop/spring 2025/BIOL 6100/Homework 9")
WD <- getwd()
build_function(c("clean_data", "extract_year", "calculate_abundance", "calculate_species_richness", "regression_analysis", "build_histogram"))

# Cleaned data folder
cleaned_data_folder <- file.path(WD, "CleanedData")

# Loop through each folder and store the cleaned data
for (i in folders[3:12]) {
  year_folder_path <- file.path(OriginalData, i)
  csv_files <- list.files(year_folder_path, pattern = "countdata.*\\.csv$", full.names = TRUE)

  for (file_path in csv_files) {
    print(file_path)  # Print file path for reference

    # Read the CSV file
    df <- read.csv(file_path)

    # Clean the data
    cleaned_df <- clean_data(df)

    # Create cleaned file name and save in CleanedData folder
    cleaned_file_name <- paste0("cleaned_", basename(file_path))
    cleaned_file_path <- file.path(cleaned_data_folder, cleaned_file_name)
    write.csv(cleaned_df, cleaned_file_path, row.names = FALSE)
    print(paste("Saved cleaned file to:", cleaned_file_path))
  }
}

# Create an initial empty data frame to hold the above summary statistics-you should have columns for the file name, one for abundance, one for species richness, one for year, and the regression model summary statistics.

cleaned_file_names <- c(list.files("CleanedData"))
DataFrame <- data.frame(Filename = cleaned_file_names)
# DataFrame <- cbind(DataFrame, Year = 1:10)

# Using a for loop, run your created functions as a batch process for each folder, changing the working directory as necessary to read in the correct files, calculating summary statistics with your created functions, and then writing them out into your summary statistics data frame.

# 2) Extract the year from each file name
years <- c()
for (i in list.files("~/Desktop/spring 2025/BIOL 6100/Homework 9/CleanedData")) {
  year_month <- extract_year(i)
  years <- c(years, year_month)
}
DataFrame <- cbind(DataFrame, Year = years)

# 3) Calculate Abundance for each year (Total number of individuals found)
setwd("/Users/audreycommerford/Desktop/spring 2025/BIOL 6100/Homework 9/CleanedData")
abundance_values <- c()
for (i in list.files("~/Desktop/spring 2025/BIOL 6100/Homework 9/CleanedData")) {
  abundance <- calculate_abundance(i)
  abundance_values <- c(abundance_values, abundance)
}
print(abundance_values)
DataFrame <- cbind(DataFrame, Abundance = abundance_values)

# 4) Calculate Species Richness for each year(Number of unique species found)
richness_values <- c()
for (i in list.files("~/Desktop/spring 2025/BIOL 6100/Homework 9/CleanedData")) {
  richness <- calculate_species_richness(i)
  richness_values <- c(richness_values, richness)
}
print(richness_values)
DataFrame <- cbind(DataFrame, SpeciesRichness = richness_values)

# 5) Run a simple regression model for Species Richness (S) vs. Abundance across all years
regression <- data.frame(regression_analysis(DataFrame))

# 6) Generate histograms for both Abundance and Species Richness (S) and store the plots
library(ggplot2)
build_histogram(DataFrame)

